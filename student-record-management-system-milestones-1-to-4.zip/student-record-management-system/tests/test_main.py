import tempfile
import unittest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from main import (
    Student, StudentDB, DuplicateRollError, StudentNotFoundError
)


class StudentDBTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.path = Path(self.temp_dir.name) / "students.dat"
        self.db = StudentDB(self.path)
        self.student = Student(101, "Asha", "BDCC", "asha@example.com",
                               1, 1, 87.5)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_insert_and_get(self):
        self.db.insert(self.student)
        self.assertEqual(self.db.get(101), self.student)

    def test_duplicate_roll_is_rejected(self):
        self.db.insert(self.student)
        with self.assertRaises(DuplicateRollError):
            self.db.insert(self.student)

    def test_update(self):
        self.db.insert(self.student)
        updated = Student(101, "Asha Patil", "BDCC", "asha@example.com",
                          1, 2, 91.0)
        self.db.update(101, updated)
        self.assertEqual(self.db.get(101), updated)

    def test_delete(self):
        self.db.insert(self.student)
        removed = self.db.delete(101)
        self.assertEqual(removed, self.student)
        with self.assertRaises(StudentNotFoundError):
            self.db.get(101)

    def test_data_persists_after_reopening(self):
        self.db.insert(self.student)
        reopened = StudentDB(self.path)
        self.assertEqual(reopened.get(101), self.student)


if __name__ == "__main__":
    unittest.main()
