"""
File-Based Student Record Management System
Milestones 1–4 | Python 3 | Binary file storage (students.dat)

Record format:
  roll_no, name, course, email, year, semester, marks, checksum

No sample records are created. Students are entered manually.
"""

from __future__ import annotations

import os
import struct
import tempfile
import zlib
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


# ------------------------- MILESTONE 2: RECORD FORMAT -------------------------

MAGIC = b"SRMS"
VERSION = 1

# Header: magic, version, number of records, generation, checksum (20 bytes)
HEADER = struct.Struct("<4sIIII")

# Record: roll, name, course, email, year, semester, marks, checksum (112 bytes)
RECORD = struct.Struct("<I48s32s16sHHfI")

DATA_FILE = Path(__file__).with_name("students.dat")


class StudentDBError(Exception):
    """Base exception for student database errors."""


class CorruptDatabaseError(StudentDBError):
    """Raised when the database header or a record is invalid."""


class DuplicateRollError(StudentDBError):
    """Raised when a roll number already exists."""


class StudentNotFoundError(StudentDBError):
    """Raised when a requested student does not exist."""


@dataclass
class Student:
    roll_no: int
    name: str
    course: str
    email: str
    year: int
    semester: int
    marks: float


def _pack_text(value: str, size: int, field: str) -> bytes:
    value = value.strip()
    encoded = value.encode("utf-8")
    if not encoded:
        raise ValueError(f"{field} cannot be empty.")
    if len(encoded) > size:
        raise ValueError(f"{field} is too long (maximum {size} UTF-8 bytes).")
    return encoded.ljust(size, b"\0")


def _unpack_text(value: bytes) -> str:
    return value.split(b"\0", 1)[0].decode("utf-8")


def _pack_student(student: Student) -> bytes:
    if not 1 <= student.roll_no <= 0xFFFFFFFF:
        raise ValueError("Roll number must be between 1 and 4294967295.")
    if not 1 <= student.year <= 0xFFFF:
        raise ValueError("Year must be a positive whole number.")
    if not 1 <= student.semester <= 0xFFFF:
        raise ValueError("Semester must be a positive whole number.")
    if not 0 <= student.marks <= 100:
        raise ValueError("Marks must be between 0 and 100.")

    body = struct.pack(
        "<I48s32s16sHHf",
        student.roll_no,
        _pack_text(student.name, 48, "Name"),
        _pack_text(student.course, 32, "Course"),
        _pack_text(student.email, 16, "Email"),
        student.year,
        student.semester,
        float(student.marks),
    )
    checksum = zlib.crc32(body) & 0xFFFFFFFF
    return body + struct.pack("<I", checksum)


def _unpack_student(raw: bytes) -> Student:
    if len(raw) != RECORD.size:
        raise CorruptDatabaseError("A student record has an invalid size.")

    body, checksum_bytes = raw[:-4], raw[-4:]
    stored_checksum = struct.unpack("<I", checksum_bytes)[0]
    actual_checksum = zlib.crc32(body) & 0xFFFFFFFF
    if stored_checksum != actual_checksum:
        raise CorruptDatabaseError("A student record failed its checksum check.")

    roll, name, course, email, year, semester, marks, _ = RECORD.unpack(raw)
    return Student(
        roll_no=roll,
        name=_unpack_text(name),
        course=_unpack_text(course),
        email=_unpack_text(email),
        year=year,
        semester=semester,
        marks=marks,
    )


def _pack_header(count: int, generation: int) -> bytes:
    body = struct.pack("<4sIII", MAGIC, VERSION, count, generation)
    checksum = zlib.crc32(body) & 0xFFFFFFFF
    return body + struct.pack("<I", checksum)


def _unpack_header(raw: bytes) -> tuple[int, int]:
    if len(raw) != HEADER.size:
        raise CorruptDatabaseError("Database header is missing or incomplete.")

    magic, version, count, generation, checksum = HEADER.unpack(raw)
    expected = zlib.crc32(raw[:-4]) & 0xFFFFFFFF

    if magic != MAGIC:
        raise CorruptDatabaseError("This is not an SRMS database file.")
    if version != VERSION:
        raise CorruptDatabaseError(f"Unsupported database version: {version}.")
    if checksum != expected:
        raise CorruptDatabaseError("Database header checksum is invalid.")

    return count, generation


# ---------------------- MILESTONE 3: DATABASE OPERATIONS ----------------------

class StudentDB:
    """Stores student records in a single binary file."""

    def __init__(self, path: Path | str = DATA_FILE):
        self.path = Path(path)
        if not self.path.exists():
            self._write_all([], generation=0)
        else:
            # Validate the file as soon as the database is opened.
            self._read_all()

    def _read_all(self) -> tuple[list[Student], int]:
        try:
            with self.path.open("rb") as file:
                header = file.read(HEADER.size)
                count, generation = _unpack_header(header)
                expected_size = HEADER.size + count * RECORD.size
                actual_size = self.path.stat().st_size
                if actual_size != expected_size:
                    raise CorruptDatabaseError(
                        "Database size does not match the record count in its header."
                    )

                students = []
                for _ in range(count):
                    raw = file.read(RECORD.size)
                    students.append(_unpack_student(raw))

                rolls = [student.roll_no for student in students]
                if len(rolls) != len(set(rolls)):
                    raise CorruptDatabaseError("Duplicate roll numbers found in database.")

                return students, generation
        except OSError as exc:
            raise StudentDBError(f"Could not read database: {exc}") from exc

    def _write_all(self, students: list[Student], generation: int) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp_name: Optional[str] = None

        try:
            with tempfile.NamedTemporaryFile(
                mode="wb", dir=self.path.parent, prefix=self.path.name + ".",
                suffix=".tmp", delete=False
            ) as file:
                temp_name = file.name
                file.write(_pack_header(len(students), generation))
                for student in students:
                    file.write(_pack_student(student))
                file.flush()
                os.fsync(file.fileno())

            os.replace(temp_name, self.path)
        except (OSError, ValueError) as exc:
            if temp_name and os.path.exists(temp_name):
                os.unlink(temp_name)
            raise StudentDBError(f"Could not save database: {exc}") from exc

    def all(self) -> list[Student]:
        students, _ = self._read_all()
        return students

    def get(self, roll_no: int) -> Student:
        for student in self.all():
            if student.roll_no == roll_no:
                return student
        raise StudentNotFoundError(f"No student found with roll number {roll_no}.")

    def insert(self, student: Student) -> None:
        students, generation = self._read_all()
        if any(item.roll_no == student.roll_no for item in students):
            raise DuplicateRollError(
                f"Roll number {student.roll_no} already exists."
            )
        students.append(student)
        students.sort(key=lambda item: item.roll_no)
        self._write_all(students, generation + 1)

    def update(self, roll_no: int, updated: Student) -> None:
        students, generation = self._read_all()
        for index, current in enumerate(students):
            if current.roll_no == roll_no:
                if updated.roll_no != roll_no and any(
                    item.roll_no == updated.roll_no for item in students
                ):
                    raise DuplicateRollError(
                        f"Roll number {updated.roll_no} already exists."
                    )
                students[index] = updated
                students.sort(key=lambda item: item.roll_no)
                self._write_all(students, generation + 1)
                return
        raise StudentNotFoundError(f"No student found with roll number {roll_no}.")

    def delete(self, roll_no: int) -> Student:
        students, generation = self._read_all()
        for index, student in enumerate(students):
            if student.roll_no == roll_no:
                removed = students.pop(index)
                self._write_all(students, generation + 1)
                return removed
        raise StudentNotFoundError(f"No student found with roll number {roll_no}.")


# -------------------------- MILESTONE 1 & 4: MENU -----------------------------

def read_int(prompt: str, minimum: int = 1) -> int:
    while True:
        try:
            value = int(input(prompt))
            if value < minimum:
                print(f"Enter a number greater than or equal to {minimum}.")
                continue
            return value
        except ValueError:
            print("Please enter a valid whole number.")


def read_marks() -> float:
    while True:
        try:
            value = float(input("Enter marks (0-100): "))
            if 0 <= value <= 100:
                return value
            print("Marks must be between 0 and 100.")
        except ValueError:
            print("Please enter a valid number.")


def input_student(roll_no: Optional[int] = None) -> Student:
    if roll_no is None:
        roll_no = read_int("Enter roll number: ")
    name = input("Enter student name: ").strip()
    course = input("Enter course: ").strip()
    email = input("Enter email (max 16 UTF-8 bytes): ").strip()
    year = read_int("Enter year: ")
    semester = read_int("Enter semester: ")
    marks = read_marks()
    return Student(roll_no, name, course, email, year, semester, marks)


def display_student(student: Student) -> None:
    print(
        f"{student.roll_no:<10} {student.name:<20} {student.course:<14} "
        f"{student.year:<6} {student.semester:<9} {student.marks:<8.2f} "
        f"{student.email}"
    )


def add_student(db: StudentDB) -> None:
    student = input_student()
    db.insert(student)
    print("Student record added successfully.")


def view_students(db: StudentDB) -> None:
    students = db.all()
    if not students:
        print("No student records found.")
        return
    print("-" * 92)
    print(f"{'Roll No':<10} {'Name':<20} {'Course':<14} {'Year':<6} "
          f"{'Semester':<9} {'Marks':<8} Email")
    print("-" * 92)
    for student in students:
        display_student(student)
    print("-" * 92)
    print(f"Total students: {len(students)}")


def search_student(db: StudentDB) -> None:
    roll_no = read_int("Enter roll number to search: ")
    display_student(db.get(roll_no))


def update_student(db: StudentDB) -> None:
    roll_no = read_int("Enter roll number to update: ")
    db.get(roll_no)  # Check that the record exists before asking for new data.
    updated = input_student(roll_no)
    db.update(roll_no, updated)
    print("Student record updated successfully.")


def delete_student(db: StudentDB) -> None:
    roll_no = read_int("Enter roll number to delete: ")
    removed = db.get(roll_no)
    print("\nStudent selected for deletion:")
    display_student(removed)
    confirm = input("Are you sure you want to delete this student? (y/n): ").strip().lower()
    if confirm == "y":
        db.delete(roll_no)
        print("Student record deleted successfully.")
    else:
        print("Delete operation cancelled.")


def main() -> None:
    try:
        db = StudentDB()
    except StudentDBError as exc:
        print(f"Database error: {exc}")
        return

    while True:
        print("\n===== STUDENT RECORD MANAGEMENT SYSTEM =====")
        print("1. Add Student")
        print("2. View All Students")
        print("3. Search Student")
        print("4. Update Student")
        print("5. Delete Student")
        print("6. Exit")

        choice = input("Enter your choice: ").strip()
        try:
            if choice == "1":
                add_student(db)
            elif choice == "2":
                view_students(db)
            elif choice == "3":
                search_student(db)
            elif choice == "4":
                update_student(db)
            elif choice == "5":
                delete_student(db)
            elif choice == "6":
                print("Thank you for using the Student Record Management System.")
                break
            else:
                print("Invalid choice. Please select 1 to 6.")
        except (StudentDBError, ValueError) as exc:
            print(f"Error: {exc}")
        except KeyboardInterrupt:
            print("\nOperation cancelled.")

if __name__ == "__main__":
    main()
