# File-Based Student Record Management System

Python project using a binary file (`students.dat`) for persistent student records.

## Milestones included

1. **Program foundation:** menu-driven application and input validation.
2. **Record format:** fixed-size binary records, file header, and CRC32 checksums.
3. **Record operations:** add, view, search, update, and delete student records.
4. **Storage layer:** persistent binary storage, validation on startup, and atomic file replacement.

## Run

Requires Python 3.10 or newer.

```bash
python main.py
```

The program creates `students.dat` automatically when first run. It does not insert sample data; enter student details manually.

## Run tests

```bash
python -m unittest discover -s tests -v
```

## GitHub upload

Create a new empty repository on GitHub, then run these commands from this project folder:

```bash
git init
git add .
git commit -m "Add student record management system through milestone 4"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```
